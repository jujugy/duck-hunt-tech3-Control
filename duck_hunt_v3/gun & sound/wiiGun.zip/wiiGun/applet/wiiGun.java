import processing.core.*; 
import processing.xml.*; 

import oscP5.*; 
import netP5.*; 

import java.applet.*; 
import java.awt.Dimension; 
import java.awt.Frame; 
import java.awt.event.MouseEvent; 
import java.awt.event.KeyEvent; 
import java.awt.event.FocusEvent; 
import java.awt.Image; 
import java.io.*; 
import java.net.*; 
import java.text.*; 
import java.util.*; 
import java.util.zip.*; 
import java.util.regex.*; 

public class wiiGun extends PApplet {




OscP5 oscP5;
NetAddress myRemoteLocation;


String button_b;
float wii1x;
float wii1y;
boolean shoot;

public void setup() {
  size(600, 600);

  button_b = "/wii/2/button/B";


  oscP5 = new OscP5(this, 12000);
  myRemoteLocation = new NetAddress("127.0.0.1", 12000);
}


public void draw() {
  background(0);  
  fill(255);
  ellipse(wii1x*width, (height-height*wii1y), 20, 20);
  if (shoot) {
    fill(255, 0, 0);
    //ellipse(wii1x*width, (wii1y*height), 20,20);
  }
}

/* incoming osc message are forwarded to the oscEvent method. */
public void oscEvent(OscMessage theOscMessage) {

  //Is it the A button (notice I declared a variable for the A button
  if (theOscMessage.checkAddrPattern("/wii/2/button/B")==true) {
    shoot = true;
    println("shoot!");
  }
  else {
    shoot = false;
  }

println(shoot);
  wii1x = theOscMessage.get(0).floatValue();
  wii1y = theOscMessage.get(1).floatValue();

  // println("X: " + wii1x*width+" Y: "+wii1y*height);
}

  static public void main(String args[]) {
    PApplet.main(new String[] { "--bgcolor=#FFFFFF", "wiiGun" });
  }
}
